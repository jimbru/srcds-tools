// Offset
new OffsetMoney;
new OffsetArmor;
new OffsetHelm;
new OffsetDefuser;
new OffsetMovement;
new OffsetFlags;
new OffsetHostage;
new m_hMyWeapons;
new OffsetWeaponParent;
new g_iOffs_iPrimaryAmmoType = INVALID_OFFSET;
