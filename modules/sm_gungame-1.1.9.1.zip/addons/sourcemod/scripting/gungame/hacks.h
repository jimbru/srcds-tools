new Handle:GameConf;

new Handle:CSWeaponDrop;
new Handle:RemoveAmmo;
new Handle:EndMultiplayerGame;
new Handle:GetSlot;
new Handle:UTILRemove;

